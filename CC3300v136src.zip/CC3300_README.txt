Requirements

Delphi7 or later
Async Pro 4.06 components, which can be found here
http://sourceforge.net/projects/tpapro/

Install and configure tpapro in Delphi IDE
before you load cc3300 project.

You can freely use this code in your own sw projects.

73's de OH1GIU 

