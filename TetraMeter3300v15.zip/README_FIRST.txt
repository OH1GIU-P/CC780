TetraMeter version 1.5

TetraMeter version 1.5 is more advanced version. It will be further developed.
(Version 1.2 is simple and fast for those who need a basic version)

TetraMeter3300 is a Tetra signal interceptor for the Uniden Bearcat UBC-3300XLT,
it should also work with UBC-780XLT

It sniffs signal strength levels and alerts if signal level goes over limit setting.
There are two limit settings, one for DMO and one for TMO uplink. Currently
the program is configured with Finnish VIRVE frequencies, but it should be
very easy to code it for other TETRA bands.

*** IMPORTANT! ***
if general mode is checked, then it is not examined if frequency is VIRVE DMO or TMO.


The program is written with Delphi7 and it uses AsyncPro components
(http://sourceforge.net/projects/tpapro/)

Uniden scanners lock into TETRA pii/4DQPSK signals quite badly, but when
one manually opens squelch there could be lotsa signal level bars on the screen.
So, there could be signal level bars but Uniden just scans, the solution is
to monitor signal levels with software. You can use e.g. CC3300 virtual3300 and
channel scope screens to monitor TETRA signal levels to determine optimum
alert levels for the TetraMeter3300. 


Write to log file check box activates logging to file. The file is named
SGLOG.TXT and it is stored into the directory where TetraMeter3300 is located.
It appends to the end of file, so old one is not deleted. 


Version 1.5 includes also Window voltage level monitoring and signal spectrum.
For more information about signal strength (SG) and window voltage level (WI):
http://www.freqofnature.com/software/protocols.html

Planned for the TetraMeter3300 version 1.5 future versions
- C++ 