//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CPort.hpp"
#include <Menus.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
        TComPort *ComPort;
        TMainMenu *MainMenu;
        TMenuItem *menuFile;
        TMenuItem *itemExit;
        TMenuItem *menuHelp;
        TMenuItem *itemAbout;
        TPanel *panelMain;
        TButton *pbConnect;
        TButton *pbStart;
        TButton *pbStop;
        TTrackBar *tbSG;
        TLabel *lbSG;
        TStatusBar *stMain;
        TCheckBox *cbBA;
        TLabel *Label1;
        TLabel *lbAlert;
        TLabel *Label2;
        TLabel *lbLastAlert;
        TCheckBox *cbLOG;
        TLabel *lbG;
        TLabel *lbGMin;
        TLabel *lbGMax;
        TLabel *lbGMinVal;
        TLabel *lbGMaxVal;
        TLabel *lbGCnt;
        TLabel *lbGCntVal;
        TLabel *lbAvals;
        TLabel *lbACnt;
        TLabel *lbACntVal;
        TLabel *lbAMin;
        TLabel *lbAMinVal;
        TLabel *lbAMax;
        TLabel *lbAMaxVal;
        TLabel *lbGAvg;
        TLabel *lbGAvgVal;
        TLabel *lbAAvg;
        TLabel *lbAAvgVal;
        void __fastcall ComPortRxChar(TObject *Sender, int Count);
        void __fastcall itemExitClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall itemAboutClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall tbSGChange(TObject *Sender);
        void __fastcall pbConnectClick(TObject *Sender);
        void __fastcall pbStartClick(TObject *Sender);
        void __fastcall cbBAClick(TObject *Sender);
        void __fastcall pbStopClick(TObject *Sender);
        void __fastcall cbLOGClick(TObject *Sender);
private:	// User declarations
        void InitValues(void);
public:		// User declarations
        __fastcall TfrmMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif
